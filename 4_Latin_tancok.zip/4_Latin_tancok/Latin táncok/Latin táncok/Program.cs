﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Latin_táncok
{
	class Tánc
	{
		public string tanc;
		public string lany;
		public string fiu;
		
		
	}
	internal class Program
	{
		static List<Tánc> lista = new List<Tánc>();
		static void beolvas()
		{
			StreamReader sr = new StreamReader("tancrend.txt");
			while (!sr.EndOfStream)
			{
				Tánc uj = new Tánc();
				uj.tanc = sr.ReadLine();
				uj.lany = sr.ReadLine();
				uj.fiu = sr.ReadLine();
				lista.Add(uj);

			}
			sr.Close();
		}
		static void kiir()
		{
			foreach (var item in lista)
			{
				Console.WriteLine(item.fiu);

			}
		}
		static void f2()
		{
			Console.WriteLine("2.feladat");
			Console.WriteLine($"Az elsőként bemutatott tánc: {lista.Select(x=>x.tanc).First()}");
			Console.WriteLine($"Az utolsóként bemutatott tánc: {lista.Select(x=>x.tanc).Last()}");
		}
		static void f3()
		{
			Console.WriteLine("3.feladat");
			int darab = 0;
			foreach (var item in lista)
			{
				if (item.tanc=="samba")
				{
					darab++;
				}

			}
			Console.WriteLine($"A samba nevű táncot {darab} alkalommal mutatták be");

		}
		static void f4()
		{
			Console.WriteLine("4.feladat");
			Console.WriteLine("Vilma a következő táncokba szerepelt:");
			foreach (var item in lista)
			{
				if (item.lany=="Vilma")
				{
					Console.WriteLine($"{item.tanc}");

				}

			}
		}
		static void f5()
		{
			Console.WriteLine("5.feladat");
			int darab = 0;
			Console.WriteLine("Adja meg egy tánc nevét: ");
			string dance = Console.ReadLine();
			for (int i = 0; i < lista.Count(); i++)
			{
				if (lista[i].tanc==dance && lista[i].lany=="Vilma")
				{
					Console.WriteLine($"A {dance} bemutatóján Vilma párja {lista[i].fiu} volt");
					darab++;

					

				}
				

			}
			if (darab==0)
			{
				Console.WriteLine($"Vilma nem táncolt {dance}-t");

			}
		}
		static void f6()
		{
			Console.WriteLine("6.feladat");
			StreamWriter sr = new StreamWriter("szereplok.txt");
			List<string>fiuk=new List<string>();
			List<string>lanyok=new List<string>();
			foreach (var item in lista)
			{
				fiuk.Add(item.fiu);
				lanyok.Add(item.lany);
				
			}
            sr.WriteLine("Lányok: " + string.Join(", ", lanyok.Distinct()));
            sr.WriteLine("Fiúk: " + string.Join(", ", fiuk.Distinct()));
            sr.Close();

		}
		static void f7()
		{
			Console.WriteLine("7.feladat");
			Dictionary<string,int> stat= new Dictionary<string,int>();
			foreach (var item in lista)
			{
				string kulcs = item.fiu;
				if (!stat.ContainsKey(kulcs))
				{
					stat.Add(kulcs,0);

				}
					stat[kulcs]++;

			}
			int legnagyobbfiu=stat.Values.Max();
			foreach (var item in stat)
			{
				if (item.Value==legnagyobbfiu)
				{
					Console.WriteLine($"A legtöbbet szereplt fiú: {item.Key}, {item.Value} alkalommal");

				}

			}
            Dictionary<string, int> stat2 = new Dictionary<string, int>();
            foreach (var item in lista)
            {
                string kulcs = item.lany;
                if (!stat2.ContainsKey(kulcs))
                {
                    stat2.Add(kulcs, 0);

                }
                stat2[kulcs]++;

            }
            int legnagyobblany = stat2.Values.Max();
            foreach (var item in stat2)
            {
                if (item.Value == legnagyobblany)
                {
                    Console.WriteLine($"A legtöbbet szereplt lány: {item.Key}, {item.Value} alkalommal");

                }

            }

        }
		static void Main(string[] args)
		{
			beolvas();
			//kiir();
			f2();
			f3();
			f4();
			f5();
			f6();
			f7();

			Console.ReadKey();
		}
	}
}
